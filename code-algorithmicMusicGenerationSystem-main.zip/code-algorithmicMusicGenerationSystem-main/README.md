# code-algorithmicMusicGenerationSystem

Code: Algorithmic Music Generation System used in closed loop affective music BCI.

Upon use, please cite / credit:

Ehrlich, S. K., Agres, K. R., Guan, C., & Cheng, G. (2019). A closed-loop, music-based brain-computer interface for emotion mediation. PloS one, 14(3), e0213516. 
URL/DOI: https://doi.org/10.1371/journal.pone.0213516
